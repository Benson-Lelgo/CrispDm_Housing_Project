# Load libraries
library(shiny)
library(shinydashboard)
library(DT)
library(randomForest)
library(ggplot2)
library(dplyr)

# Loading the trained model and scaler
rf_model <- readRDS("../models/rf_model.rds")
scaler <- readRDS("../models/scaler_object.rds")

# Defining UI
ui <- dashboardPage(
  dashboardHeader(title = "Housing Price Predictor"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Prediction", tabName = "predict", icon = icon("home")),
      menuItem("Model Info", tabName = "model", icon = icon("chart-line")),
      menuItem("About", tabName = "about", icon = icon("info-circle"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "predict",
              fluidRow(
                box(title = "Property Features", width = 6, status = "primary",
                    numericInput("LND_SQFOOT", "Land Area (sqft):", 7500),
                    numericInput("TOT_LVG_AREA", "Living Area (sqft):", 2000),
                    numericInput("SPEC_FEAT_VAL", "Special Features Value:", 10000),
                    numericInput("RAIL_DIST", "Distance to Rail (ft):", 8000),
                    numericInput("OCEAN_DIST", "Distance to Ocean (ft):", 30000),
                    numericInput("WATER_DIST", "Distance to Water (ft):", 5000),
                    numericInput("CNTR_DIST", "Distance to Center (ft):", 50000),
                    numericInput("SUBCNTR_DI", "Distance to Subcenter (ft):", 40000),
                    numericInput("HWY_DIST", "Distance to Highway (ft):", 8000),
                    numericInput("age", "Property Age (years):", 30),
                    selectInput("structure_quality", "Structure Quality:", choices = 1:5),
                    actionButton("predict", "Predict Price", class = "btn-success")
                ),
                box(title = "Prediction Result", width = 6, status = "info",
                    h3("Estimated Property Value:"),
                    verbatimTextOutput("prediction"),
                    hr(),
                    h4("Engineered Features:"),
                    verbatimTextOutput("engineered_features")
                )
              )
      ),
      tabItem(tabName = "model",
              h2("Model Performance"),
              DTOutput("model_performance"),
              plotOutput("model_plot")
      ),
      tabItem(tabName = "about",
              h2("About This App"),
              p("This application predicts house prices based on a Random Forest model trained using CRISP-DM methodology."),
              p("Adjust the input parameters on the Prediction tab to get an estimated house price.")
      )
    )
  )
)

# Defining Server
server <- function(input, output, session) {

  get_input_data <- reactive({
    df <- data.frame(
      LND_SQFOOT = input$LND_SQFOOT,
      TOT_LVG_AREA = input$TOT_LVG_AREA,
      SPEC_FEAT_VAL = input$SPEC_FEAT_VAL,
      RAIL_DIST = input$RAIL_DIST,
      OCEAN_DIST = input$OCEAN_DIST,
      WATER_DIST = input$WATER_DIST,
      CNTR_DIST = input$CNTR_DIST,
      SUBCNTR_DI = input$SUBCNTR_DI,
      HWY_DIST = input$HWY_DIST,
      age = input$age,
      avno60plus = 0,
      structure_quality = factor(input$structure_quality, levels = 1:5),
      month_sold = 6,
      living_area_to_land_ratio = input$TOT_LVG_AREA / input$LND_SQFOOT,
      proximity_to_locations_score = input$RAIL_DIST + input$OCEAN_DIST + input$WATER_DIST +
                                     input$CNTR_DIST + input$SUBCNTR_DI + input$HWY_DIST
    )
    df
  })

  get_scaled_data <- reactive({
    input_data <- get_input_data()
    for (feature in names(scaler$mean)) {
      input_data[[feature]] <- (input_data[[feature]] - scaler$mean[[feature]]) / scaler$std[[feature]]
    }
    input_data
  })

  prediction <- reactive({
    predict(rf_model, get_scaled_data())
  })

  output$prediction <- renderText({
    paste0("$", format(round(prediction(), 0), big.mark = ","))
  })

  output$engineered_features <- renderText({
    input_data <- get_input_data()
    paste(
      "Living Area to Land Ratio:", round(input_data$living_area_to_land_ratio, 4), "\n",
      "Proximity Score:", round(input_data$proximity_to_locations_score, 0), "ft"
    )
  })

  output$model_performance <- renderDT({
    datatable(data.frame(
      Model = "Random Forest",
      Parameters = "mtry=6, ntree=500",
      RMSE = 94118.81,
      R_Squared = 0.9037
    ), options = list(dom = 't'))
  })

  output$model_plot <- renderPlot({
    df <- data.frame(
      Metric = factor(c("RMSE", "R²"), levels = c("RMSE", "R²")),
      Value = c(94118.81, 0.9037)
    )

    ggplot(df, aes(x = Metric, y = Value, fill = Metric)) +
      geom_col() +
      geom_text(aes(label = round(Value, 3)), vjust = -0.5) +
      scale_y_continuous(labels = scales::comma) +
      labs(title = "Model Performance on Test Data", y = "") +
      theme_minimal() +
      theme(legend.position = "none")
  })
}

# Launch the app
shinyApp(ui = ui, server = server)
