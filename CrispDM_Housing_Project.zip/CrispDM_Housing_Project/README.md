# 🏠 CRISP-DM Project: Housing Price Prediction Using Machine Learning

## 📌 Overview

This project applies the CRISP-DM methodology to build a machine learning pipeline for predicting house prices based on structured housing data. The goal is to develop, evaluate, and deploy multiple predictive models and provide an interactive Shiny dashboard for users to estimate home values.

---

## 🧠 Objectives

- Apply CRISP-DM steps to a real-world regression task
- Perform feature engineering and data preprocessing
- Train and evaluate multiple machine learning models (Decision Tree, Random Forest, SVM, XGBoost)
- Deploy a Random Forest model via a Shiny web dashboard
- Enable user interaction for prediction using real estate features

---

## 📁 Project Structure

```
CrispDm_Housing_Project/
├── app/                    # Contains Shiny app code
│   └── app.R
├── data/                   # Housing dataset
│   └── housing_data.csv
├── models/                 # Saved model and scaler for use in the app
│   ├── rf_model.rds
│   └── scaler_object.rds
├── housing_model.Rmd       # Full R Markdown analysis (CRISP-DM)
├── housing_model.html      # Knitted HTML report
└── README.md               # This file
```

---

## 📊 Dataset Description

The dataset includes features such as:

- `LND_SQFOOT`: Land size
- `TOT_LVG_AREA`: Living area
- `RAIL_DIST`, `OCEAN_DIST`, etc.: Distances to key infrastructure
- `SPEC_FEAT_VAL`: Value of special features
- `structure_quality`: Quality rating of the structure (1–5)
- `SALE_PRC`: Target variable (house sale price)

---

## 🔧 Technologies Used

- **R**: Data processing, modeling, and reporting
- **Caret**, **randomForest**, **xgboost**, **e1071**: ML packages
- **Shiny + shinydashboard**: Interactive dashboard
- **DT** and **ggplot2**: Output tables and plots

---

## 📈 Modeling & Evaluation

The following models were trained and evaluated:

| Model            | RMSE     | R²       |
|------------------|----------|----------|
| Random Forest    | 94,118   | 0.90     |
| Decision Tree    | ~        | ~        |
| SVM (Linear/RBF) | ~        | ~        |
| XGBoost          | ~        | ~        |

> The best model (Random Forest) was selected for deployment via Shiny.

---

## 🚀 How to Run the App

1. Clone the repo or download the ZIP.
2. Open `app/app.R` in RStudio.
3. Ensure the following files exist:
   - `models/rf_model.rds`
   - `models/scaler_object.rds`
4. Run the app with:

```r
shiny::runApp("app")
```

---

## 📬 Contact

**Author**: Benson Lelgo  
**Institution**: University of Bolton  
**Course**: MSc Business Analytics and Technologies – DAT7303

---

## 📜 License

This project is for academic use only. Do not use or redistribute the model for commercial applications without permission.
